class Main {
  public static void main(String[] args) {
    System.out.println("Hello world!");
    int x = 99;
    while (x > 0) {
      System.out.println(x + " bottles of beer on the wall");
      x--;
      System.out.println("take one down, pass it around ");
    }
    if (x <= 1) {
      System.out.println("no more bottles of beer on the wall");
    }
  }
}
