public class Sphere {
  //member variables
  private double r;
  //constructor
  public Sphere (){
    r = 0.0;
  }

  public void setR(double r) {
    this.r=r;
  }
//calculate 
  public double calcVal () {
    double val = Math.PI*(r*r*r)*4/3;
    return val;
  }

  public double CalcSur () {
    double sa = 4*Math.PI*(r*r); 
    return sa;
  }
}