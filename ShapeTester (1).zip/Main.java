import java.util.Scanner;
import java.lang.Math;

class Main {
  public static void main(String[] args) {

    Scanner scan = new Scanner(System.in);

    Box b1 = new Box();
    Sphere s1 = new Sphere();
    double val = 0.0;
    Pyramid p1 = new Pyramid();

    System.out.println("Welcome to the shape tester!");
    System.out.println(" ");
    System.out.println("To find the surface area and volume of a box");
    System.out.println("Please enter box length");
    val = scan.nextDouble();
    b1.setL(val);
    System.out.println(" ");

    System.out.println("Please enter box wdith");
    val = scan.nextInt();
    b1.setW(val);
    System.out.println(" ");

    System.out.println("Please enter box height");
    val = scan.nextInt();
    b1.setH(val);
    System.out.println(" ");

    System.out.println("Volume: " + b1.calcVal());
    System.out.println("Surface Area: " + b1.CalcSur());
    System.out.println(" ");

    // sphere
    System.out.println("To find the surface area and volume of a sphere");
    System.out.println(" ");
    System.out.println("Please enter sphere radius");
    val = scan.nextDouble();
    s1.setR(val);
    System.out.println(" ");

    System.out.println("Volume: " + s1.calcVal());
    System.out.println("Surface Area: " + s1.CalcSur());
    System.out.println(" ");

    // pyramid
    System.out.println("To find the surface area and volume of a pyramid");
    System.out.println(" ");
    System.out.println("Please enter pyramid base length");
    val = scan.nextDouble();
    p1.setL(val);
    System.out.println(" ");

    System.out.println("Please enter pyramid base width");
    val = scan.nextDouble();
    p1.setW(val);
    System.out.println(" ");

    System.out.println("Please enter pyramid height");
    val = scan.nextDouble();
    p1.setH(val);
    System.out.println(" ");

    System.out.println("Volume: " + p1.calcVal());
    System.out.println("Surface Area: " + p1.CalcSur());
    System.out.println(" ");

    System.out.println("Thank you for playing!");
  }
}