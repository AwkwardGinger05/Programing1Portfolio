public class Box {
  //member variables
  private double l;
  private double w;
  private double h;
  //constructor
  public Box (){
    w = 0.0;
    l = 0.0;
    h = 0.0;
  }

  public void setL(double l) {
    this.l=l;
  }
  public void setW(double w) {
    this.w=w;
  }
  public void setH(double h) {
    this.h=h;
  }
//calculate 
  public double calcVal () {
    double val = l*h*w;
    return val;
  }

  public double CalcSur () {
    double sa = 2*(l*w + l*h +w*h);
    return sa;
  }
}